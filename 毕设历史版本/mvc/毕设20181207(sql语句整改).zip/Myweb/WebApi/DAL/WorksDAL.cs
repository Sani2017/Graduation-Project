﻿using Common;
using Models;
using Models.ModelTemplate;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAl.Models;
namespace DAL
{

    public class WorksDAL
    {
        /// <summary>
        /// 关于作品表的sql操作
        /// </summary>
        SqlSugarClient db;
        public WorksDAL()
        {
            db = SqlSugarClientHelper.SqlSugarDB();
        }
        /// <summary>
        /// 查询所有作品表内容sql
        /// </summary>
        /// <returns></returns>
        public TMessage<List<Works>> GetWorksInfo()
        {
            TMessage<List<Works>> mes = new TMessage<List<Works>>();
            var getAll = db.Queryable<Works>()
                //.OrderBy(it => it.CreatedAt,OrderByType.Desc)到这里了，关于用户个人的作品输出
                //有类似但不知道在哪里
                .Where(it => it.IsDeleted !=(int)Common.EnumType.StateResolution.OneType)//.ToSql();
                .ToList();
            if (getAll.Count < 1)
            {
                mes.suc = false;
                mes.mes = ConstHelper.GET_LIST_ERROR +","+ getAll.Count + "条";
            }
            else {
                mes.suc = true;
                mes.mes=ConstHelper.GET_LIST_SUCCESS;
                mes.extra = getAll;
            }
            Console.WriteLine(getAll);
            return mes;
        }
        //where（it=>it.aa="某作者"）.count()
        /// <summary>
        /// 修改作品表内容sql
        /// </summary>
        /// <returns>object</returns>
        public TMessage<Works> UpdateWorksInfo(WorkModel model)
        {
            TMessage<Works> mes = new TMessage<Works>();

            //4.指定对象更新，需要先获取在修改
            Works work = db.Queryable<Works>()
                .Where(q => q.Id == model.Id)
                .First();
            Works NewWorks = new Works();
            //实体类与公共类比较
            if (!work.AllowShow.Equals(model.AllowShow)) { work.AllowShow = model.AllowShow; }//是否允许展示
            if (!work.IsDeleted.Equals(model.IsDeleted)) { work.IsDeleted = model.IsDeleted; }//是否标识已删除
            if (!work.Sort.Equals(model.Sort)) { work.Sort = model.Sort; }//作品分类
            if (!work.ActivityId.Equals(model.ActivityId)) { work.ActivityId = model.ActivityId; }//活动ID
            if (!work.FileAddress.Equals(model.FileAddress)) { work.FileAddress = model.FileAddress; }//文件地址
            if (!work.Content.Equals(model.Content)) { work.Content = model.Content; }//内容简介
            if (!work.Title.Equals(model.Title)) { work.Title = model.Title; }//标题
            work.PublishedAt = DateTime.Now.ToLocalTime();//发布时间（管理员发布）
            work.CreatedAt = work.CreatedAt;//创建时间（用户创建）
            var result4 = db.Updateable(work).ExecuteCommand();//db.Updateable(work);//.ExecuteCommand(); 
            //Console.WriteLine(result4);
            if (result4 == 1)
            {
                mes.suc = true;
                mes.mes = ConstHelper.UPDATE_MODEL_SUCCESS;
            }
            else {
                mes.suc = false;
                mes.mes = ConstHelper.UPDATE_MODEL_ERROR;
            }
            return mes;//result4;
        }

         ///<summary>
         ///根据作者Id去获取相应的作品数量sql
         ///</summary>
         ///<returns></returns>
        public object GetWorksInfoByAuthorId(int AuthorId)
        {
            TMessage<Works> mes = new TMessage<Works>();
            int getAll = db.Queryable<Works>()
                .Where(wk => wk.AuthorId == AuthorId)
                .Count();
            mes.suc = true;
            mes.mes = getAll.ToString();
            return mes;
        }
        /// <summary>
        /// 获取点赞榜排名与用户表关联
        /// </summary>
        /// <returns>
        /// 有个想法，将栏目更改成排行榜，
        /// 有个下拉列表类表选中什么就以什么作为条件输出排行榜
        /// </returns>
        public object GetAllWorksLikesCountInfo() {
            var AllList = db.Queryable<Works, UserInfo,Sort>((wk, ui,st) => new object[] {
                JoinType.Right, ui.Id == wk.AuthorId,
                JoinType.Left,st.Id==wk.Sort 

            })
                // .GroupBy(ui => new { ui.Id, ui.UserName })
               // .OrderBy((wk, ui) => ui.Id, OrderByType.Asc)//id是顺序
                .OrderBy((wk) => wk.LikesCount, OrderByType.Desc)//点赞是倒叙

                .Select((wk, ui,st) => new
                {
                    UserId = ui.Id,//用户id
                    UserName = ui.UserName,//用户名
                    UserImg = ui.UserImg,//用户头像
                    WorksId = wk.Id,//作品id
                    Title = wk.Title,//标题
                    Content = wk.Content,//内容
                    Sort = st.SortName,//作品分类
                   // AllowShow = wk.AllowShow,
                    LikesCount = wk.LikesCount,//点赞量
                    //CreatedAt = wk.CreatedAt,
                    PublishedAt = wk.PublishedAt//发布时间

                })//.ToSql();
                   .ToList();

            return AllList;//.GroupBy(ui => ui.UserName);//分组，大集合嵌套小集合

        }
        /// <summary>
        /// 输出作品与用户信息列表，用于首页等
        /// </summary>
        /// <returns>
        /// 添加状态：
        ///     最新发布：0
        ///     赞数最多：1
        ///     浏览最多：2
        /// </returns>
        public object GetWorkAndUserInfoList(int lookState) {
            string orderByState ="";
            switch(lookState){
                case 0:
                    orderByState = "PublishedAt Desc";//时间倒叙
                    break;
                case 1:
                    orderByState = "LikesCount Desc";//赞数倒叙
                    break;
                case 2:
                    orderByState = "Hits Desc";//浏览量倒叙
                    break;
                default:
                    orderByState = "PublishedAt Desc";//时间倒叙
                    break;
            }
            //TMessage<List<IndexWorksListModel>> mes = new TMessage<List<IndexWorksListModel>>();
            var AllList = db.Queryable<Works, UserInfo, Sort>((wk, ui, st) => new object[] {
                JoinType.Left, ui.Id == wk.AuthorId,
                JoinType.Left,st.Id==wk.Sort 

            })
                // .GroupBy(ui => new { ui.Id, ui.UserName })
                // .OrderBy((wk, ui) => ui.Id, OrderByType.Asc)//id是顺序
                // .OrderBy((wk) => wk.LikesCount, OrderByType.Desc)//点赞是倒叙
            .Select((wk, ui, st) => new IndexWorksListModel//这个很重要
            {
                WorkImg = wk.WorkImg,//作品封面
                WorksId = wk.Id,//作品id
                WorksTitle = wk.Title,//标题
                LikesCount = wk.LikesCount,//点赞量
                Hits = wk.Hits,//浏览量
                PublishedAt = wk.PublishedAt,//发布时间
                UserId = ui.Id,//用户id
                UserName = ui.UserName,//用户名
                UserImg = ui.UserImg,//用户头像
                WorksSort = st.SortName,//作品分类
            })//.ToSql();
            .Mapper((it, cache) =>
            {
                if (it.PublishedAt != null)
                {
                    DateTime dt1 = DateTime.Now;//当前时间
                    DateTime dt2 = DateTime.Parse(it.PublishedAt.ToString());//数据库存入时间
                    TimeSpan ts = dt1 - dt2;
                    if (ts.Days != 0)
                    {
                        if (ts.Days >= 365)
                        {
                            it.TimeDifference = "一年前";
                        }
                        else { 
                           it.TimeDifference = ts.Days.ToString() + "天";//超过365 显示一年前
                        }
                    }
                    else if (ts.Hours != 0)
                    {
                        it.TimeDifference = ts.Hours.ToString() + "小时";
                    }
                    else if (ts.Minutes != 0)
                    {
                        it.TimeDifference = ts.Minutes.ToString()+ "分钟";
                    }
                    else if (ts.Seconds != 0)
                    {
                        it.TimeDifference = ts.Seconds.ToString() + "秒";
                    }
                }
                else
                {
                    it.TimeDifference = "...";
                }

                //it.TimeDifference = ts.ToString();//// = it.PublishedAt.ToString();DateTime.Now; 

            })
            .Take(50)
            .OrderBy("" + orderByState + "")//发布时间是倒叙
            //.ToSql();
            .ToList();
            //DateTime dt11 = DateTime.Now;//当前时间
            //DateTime dt12 = DateTime.Parse("2011-09-26 16:19:02");//数据库存入时间
            //TimeSpan ts1 =  dt11 -dt12;
            //string TimeDifference = "";
            //if (ts1.Days != 0)
            //{
            //    if (ts1.Days >= 365)
            //    {
            //        TimeDifference = "一年前";
            //    }
            //    else
            //    {
            //        TimeDifference = ts1.Days.ToString().Substring(1) + "天";//超过365 显示一年前
            //    }
            //}

            //mes.extra = AllList;
            return AllList;
            //DateTime aaa=  DateTime.Now.ToLocalTime();
            //DateTime bbb= DateTime.Now;
            //return new { Data = AllList};//返回多個值。
            //.GroupBy(ui => ui.UserName);//分组，大集合嵌套小集合
        }
        /// <summary>
        /// 批量删除作品信息
        /// </summary>
        /// <param name="deleBatchById">删除的作品id</param>
        /// <returns></returns>
        public object DeleBatchWorksInfo(int[] deleBatchById)
        {
            TMessage<Works> mes = new TMessage<Works>();
            var t4 = db.Deleteable<Works>().Where(it => deleBatchById.Contains(it.Id)).ExecuteCommand();//.ToSql();//.In(new int[] { 1,2,3}).ToSql();//.ExecuteCommand();
            if (t4 >= 1)
            {
                mes.suc = true;
                mes.mes = ConstHelper.DELETE_MODEL_SUCCESS + t4 + "条";
            }
            else
            {
                mes.suc = false;
                mes.mes = ConstHelper.GET_NOTHING + "," + ConstHelper.DELETE_MODEL_ERROR;
            }
            return mes;
        }
        /// <summary>
        /// 批量软删除作品信息update
        /// </summary>
        /// <param name="Id">软删除作品id</param>
        /// <returns></returns>
        public object UpdateWorkIsDeleted(int[] Id ) {
            TMessage<Works> mes = new TMessage<Works>();

            var updatIsDeleted = //db.Updateable<Works>().Where(it => Id.Contains(it.Id)).ExecuteCommand();//.ToSql();//.In(new int[] { 1,2,3}).ToSql();//.ExecuteCommand();
                db.Updateable<Works>().
                UpdateColumns(it => new Works() { IsDeleted = (int)Common.EnumType.StateResolution.OneType }).
                Where(it => Id.Contains(it.Id)).ExecuteCommand();//.ToSql();//
            //db.Updateable<Student>().UpdateColumns(it => new Student()
            //{ Name = it.Name+1}).Where(it => it.Id == 11).ExecuteCommand();
            if (updatIsDeleted >= 1)
            {
                mes.suc = true;
                mes.mes = ConstHelper.DELETE_MODEL_SUCCESS + updatIsDeleted + "条";
            }
            else
            {
                mes.suc = false;
                mes.mes = ConstHelper.GET_NOTHING + "," + ConstHelper.DELETE_MODEL_ERROR;
            }
            return mes;
        
        }
        /// <summary>
        /// 根据是否删除的状态去删除作品信息（定时）
        /// </summary>
        /// <param name="isDeleted">是否标识已删除[1:是，0:否],默认值:0</param>
        /// <returns></returns> async Task<int>
        public object DelWorkInfoByIsDeleted()
        {
            //删除所有isDeleted不等于0的信息
            //List<int> list = new List<int>() { 1, 3 };!list.Contains(
            var t5 = db.Deleteable<Works>().Where(it => it.IsDeleted != 0).ExecuteCommand();//.ToSql();//
            return t5;
        }
        /// <summary>
        /// 增加留言的点赞量
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public object UpdatWorksLikes(int id)
        {
            TMessage<Works> mes = new TMessage<Works>();

            var updateLikes = db.Updateable<Works>()
                .UpdateColumns(it => new Works() { LikesCount = it.LikesCount + 1 })
                .Where(it => it.Id == id).ExecuteCommand();
            if (updateLikes < 1)
            {
                mes.suc = false;
                mes.mes = ConstHelper.UPDATE_MODEL_ERROR;
            }
            else
            {
                mes.suc = true;
                mes.mes = ConstHelper.UPDATE_MODEL_SUCCESS;
            }
            return mes;
        }
        /// <summary>
        /// 增加作品信息
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public object AddWorksInfo(WorkModel model) {
            TMessage<Works> mes = new TMessage<Works>();
            if (!SeleUserName(model.Title)) {
                Works works = new Works();
                works.Title = model.Title;//标题
                works.Content = model.Content;//内容
                works.FileAddress = model.FileAddress;//附件地址
                works.AuthorId = model.AuthorId;//作者id
                works.AuthorName = model.AuthorName;//作者姓名
                works.ActivityId = model.ActivityId;//活动ID
                works.Sort = model.Sort;//作品类型
                works.CreatedAt = DateTime.Now.ToLocalTime();//model.CreatedAt;创建时间（用户创建）

                var t4 = db.Insertable(works).ExecuteCommand(); //.ToSql();
                if (t4 >= 1)
                {
                    mes.suc = true;
                    mes.mes = ConstHelper.INSERT_MODEL_SUCCESS + t4 + "条";
                }
                else
                {
                    mes.suc = false;
                    mes.mes = ConstHelper.INSERT_MODEL_ERROR;
                }
            }
            else
            {
                mes.suc = false;
                mes.mes = ConstHelper.NEWSTITLE_UNIQUER;
            }
            return mes;//result4;.ExecuteReturnIdentity()

        }

        /// <summary>
        /// 判断作品名称是否重复
        /// </summary>
        /// <param name="workTitle">查询用的类型名称</param>
        /// <returns></returns>
        public bool SeleUserName(string workTitle)
        {
            TMessage<Works> mes = new TMessage<Works>();

            var isAny = db.Queryable<Works>().Where(it => it.Title == workTitle).Any();

            return isAny;
        }

    }
}
