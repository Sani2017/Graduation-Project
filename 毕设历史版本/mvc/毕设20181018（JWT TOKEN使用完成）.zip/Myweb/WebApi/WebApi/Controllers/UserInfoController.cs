﻿using BLL;
using Models;
using Common.Constant;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Models.ModelTemplate;
using DAl.Models;
using Common;


namespace DAl.Controllers
{
    
    public class UserInfoController : ApiController
    {
        UserInforBLL dt = new UserInforBLL();
        /// <summary>
        /// 获取表中所有用户信息
        /// </summary>
        /// <returns></returns>
        [AcceptVerbs("Get", "Options")]
        [FunctionView("获取表中所有用户信息", OperationType.RETRIEVE)]
        [Route("api/UserInfo/GetAllUserInfo")] 

        public List<UserInfo> GetAllUserInfo()//List<post>JsonResult
        {
            return dt.AllUserInfor();
        }

        /// <summary>
        /// 获取表中所有用户作品
        /// </summary>
        /// <returns></returns>
        [AcceptVerbs("Get", "Options")]
        [FunctionView("获取表中所有用户以及作品", OperationType.RETRIEVE)]
        [Route("api/UserInfo/GetAllUserWorksInfo")] 
        public object GetAllUserWorksInfo(){
            return dt.AllUserWorksInfo();
        }

        /// <summary>
        /// 根据用户id获取用户信息
        /// </summary>
        /// <param name="Id">用户Id</param>
        /// <returns></returns>
        [AcceptVerbs("Get", "Options")]
        [FunctionView("根据用户id获取用户信息", OperationType.RETRIEVE)]
        [Route("api/UserInfo/GetUserInfoById")]
        public object GetUserInfoById(int Id)
        {
            return dt.GetUserInfoByID(Id);
        }
        /// <summary>
        /// 用户登录验证
        /// </summary>
        /// <param name="model">用户表传参model</param>
        /// <returns></returns>
        [AcceptVerbs("Post", "Options")]
        [FunctionView("用户登录验证", OperationType.LOGON)]
        [Route("api/UserInfo/UserLogin")]
        public object UserLogin(UserInfoModel model)
        {
            TMessage<UserInfo> mes = new TMessage<UserInfo>();
            if (string.IsNullOrWhiteSpace(model.UserName) 
                || string.IsNullOrWhiteSpace(model.PassWord)) {
                mes.suc=false;
                mes.mes=ConstHelper.USERNAME_PASSWORD_EMPTY;
                return mes;
            }
            return dt.UserLogin(model.UserName, model.PassWord);
            
        }
    }
}
