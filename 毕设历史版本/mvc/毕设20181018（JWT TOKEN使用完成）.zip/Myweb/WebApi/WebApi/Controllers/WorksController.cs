﻿using BLL;
using Models;
using Common.Constant;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Models.ModelTemplate;
using DAl.Models;
using Common;

namespace DAl.Controllers
{
    public class WorksController : ApiController
    {
        WorksBLL dt = new WorksBLL();
        /// <summary>
        /// 获取表中所有作品信息
        /// </summary>
        /// <returns></returns>OperationType.RETRIEVE
        [AcceptVerbs("Get", "Options")]
        [FunctionView("获取表中所有作品信息",OperationType.RETRIEVE)]
        [Route("api/Works/GetAllWorks")]
        public TMessage<List<Works>> GetAllWorks()//List<post>
        {
            return dt.AllWorks();
        }
        /// <summary>
        /// 修改作品表内容
        /// </summary>
        /// <returns>11个内容要全部上传，数据层会判断该是否更改</returns>
        [AcceptVerbs("post", "Options")]
        [FunctionView("修改作品表内容", OperationType.UPDATE)]
        [Route("api/Works/UpdateAllWorks")]
        public TMessage<Works> UpdateAllWorks(UpdateWorkModel model)
        {
            //var asd=true;添加判断model中的值是否为空
            TMessage<Works> mes = new TMessage<Works>();
            if (string.IsNullOrWhiteSpace(model.Id.ToString())){//所有传参不能为空
                mes.suc=false;
                mes.mes = ConstHelper.ID_NEEDE;
                return mes;
            }
            if(model==null){
                mes.suc = false;
                mes.mes = ConstHelper.NOT_NULL_INFORMATION_CONTENT;
                return mes;
            }
            return dt.UpdateWorksAll(model);
        }
        /// <summary>
        /// 根据作者Id去获取相应的作品数量
        /// </summary>
        /// <returns></returns>OperationType.RETRIEVE
        [AcceptVerbs("Get", "Options")]
        [FunctionView("根据作者Id获取表中作品数量", OperationType.RETRIEVE)]
        [Route("api/Works/GetWorksInfoByAuthorId")]
        public object GetWorksInfoByAuthorId(int AuthorId)
        {
            return dt.GetAllWorksInfoByAuthorId(AuthorId);
        }

        /// <summary>
        /// 获取点赞榜排名
        /// </summary>
        /// <returns></returns>
        [AcceptVerbs("Get", "Options")]
        [FunctionView("获取点赞榜排名", OperationType.RETRIEVE)]
        [Route("api/Works/GetAllWorksLikesCountInfo")]
        public object GetAllWorksLikesCountInfo()
        {
            return dt.GetAllWorksLikesCount();
        }
        /// <summary>
        /// 批量删除作品信息
        /// </summary>
        /// <param name="delBatchWorks">删除作品的id</param>
        /// <returns></returns>
        [AcceptVerbs("post", "Options")]
        [FunctionView("批量删除作品信息", OperationType.DELETE)]
        [Route("api/Works/DelBatchWorksById")]
        public object DelBatchWorksById(int[] delBatchWorks)
        {
            return dt.DeleBatchWorksInfo(delBatchWorks);
        }

        /// <summary>
        /// 修改作品的删除状态,软删除(IsDeleted,是否标识已删除)
        /// 我还要考虑一下（软删除 +  定时任务）
        /// </summary>
        [AcceptVerbs("post", "Options")]
        [FunctionView("修改作品的删除状态,软删除(IsDeleted,是否标识已删除)", OperationType.RETRIEVE)]
        [Route("api/Works/UpdateWorkIsDeleted")]
        public object UpdateWorkIsDeleted(int[] Id)
        {
            TMessage<Works> mes = new TMessage<Works>();

            return dt.UpdateWorkIsDeleted(Id);
        }

        /// <summary>
        /// 根据是否删除的状态去删除作品信息（定时）
        /// </summary>
        /// <param name="isDeleted">是否标识已删除[1:是，0:否],默认值:0</param>
        /// <returns></returns>
        [AcceptVerbs("post", "Options")]
        [FunctionView("批量删除作品信息", OperationType.DELETE)]
        [Route("api/Works/DelWorkInfoByIsDeleted")]
        public object DelWorkInfoByIsDeleted()
        {
            return dt.DelWorkInfoByIsDeleted();
        }
    }
}
