/*
Navicat MySQL Data Transfer

Source Server         : 测试
Source Server Version : 50719
Source Host           : 192.168.0.241:3306
Source Database       : tsblog

Target Server Type    : MYSQL
Target Server Version : 50719
File Encoding         : 65001

Date: 2018-10-15 16:45:01
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for Activity
-- ----------------------------
DROP TABLE IF EXISTS `Activity`;
CREATE TABLE `Activity` (
  `Id` bigint(10) NOT NULL AUTO_INCREMENT,
  `ActivityName` varchar(50) NOT NULL COMMENT '活动名称',
  `ActivityContent` varchar(255) NOT NULL COMMENT '活动简介',
  `ActivityState` int(10) DEFAULT '1' COMMENT '启用状态（1.启用，0.禁用）默认1',
  `ActivityDate` datetime DEFAULT NULL COMMENT '活动发布时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of Activity
-- ----------------------------
INSERT INTO `Activity` VALUES ('1', '3活动名称3', '123', '1', '2018-09-30 11:32:06');
INSERT INTO `Activity` VALUES ('3', '123', '2312', '0', '2018-09-30 11:32:09');
INSERT INTO `Activity` VALUES ('4', '2测试标题1', '测试内容1', '1', '2018-09-20 11:32:12');
INSERT INTO `Activity` VALUES ('5', '测试标题1', '测试内容1', '1', '2018-10-06 11:32:14');
INSERT INTO `Activity` VALUES ('6', '测试标题2', '测试内容3', '0', '2018-09-19 11:32:21');

-- ----------------------------
-- Table structure for Admin
-- ----------------------------
DROP TABLE IF EXISTS `Admin`;
CREATE TABLE `Admin` (
  `Id` int(10) NOT NULL AUTO_INCREMENT COMMENT '管理员表ID编号',
  `AdminName` varchar(50) NOT NULL COMMENT '管理员登录名',
  `AdminPwd` varchar(50) NOT NULL COMMENT '管理员密码',
  `AdminRight` int(5) NOT NULL DEFAULT '2' COMMENT '管理员权限（默认:2，一般，1最高）',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of Admin
-- ----------------------------

-- ----------------------------
-- Table structure for Online
-- ----------------------------
DROP TABLE IF EXISTS `Online`;
CREATE TABLE `Online` (
  `Id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `Uid` int(10) NOT NULL COMMENT '留言人id',
  `Content` varchar(255) COLLATE utf8_bin NOT NULL COMMENT '留言内容',
  `Creatime` datetime DEFAULT NULL COMMENT '留言时间',
  PRIMARY KEY (`Id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_bin ROW_FORMAT=COMPACT;

-- ----------------------------
-- Records of Online
-- ----------------------------
INSERT INTO `Online` VALUES ('1', '1', '留的这是一条留言', '2018-04-02 20:58:32');
INSERT INTO `Online` VALUES ('2', '2', '留的这是二条留言', '2018-04-27 15:36:13');

-- ----------------------------
-- Table structure for Reply
-- ----------------------------
DROP TABLE IF EXISTS `Reply`;
CREATE TABLE `Reply` (
  `Id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `Cid` int(11) NOT NULL COMMENT '留言id',
  `Uid` varchar(11) COLLATE utf8_bin NOT NULL COMMENT '回复人id',
  `Recontent` varchar(255) COLLATE utf8_bin NOT NULL COMMENT '回复内容',
  `Retime` datetime DEFAULT NULL COMMENT '回复时间',
  PRIMARY KEY (`Id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_bin ROW_FORMAT=COMPACT;

-- ----------------------------
-- Records of Reply
-- ----------------------------
INSERT INTO `Reply` VALUES ('1', '1', '2', '第二人回复第1条留言', null);
INSERT INTO `Reply` VALUES ('2', '2', '2', '第二人回复第2条留言', null);
INSERT INTO `Reply` VALUES ('3', '1', '1', '第一人回复第1条留言', null);
INSERT INTO `Reply` VALUES ('4', '2', '2', '第二人回复第2条留言2次', null);
INSERT INTO `Reply` VALUES ('5', '2', '1', '第一人回复第2条留言', null);

-- ----------------------------
-- Table structure for Sort
-- ----------------------------
DROP TABLE IF EXISTS `Sort`;
CREATE TABLE `Sort` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '活动ID',
  `SortName` varchar(255) NOT NULL COMMENT '类型名称',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of Sort
-- ----------------------------
INSERT INTO `Sort` VALUES ('1', 'web');
INSERT INTO `Sort` VALUES ('2', 'UI');
INSERT INTO `Sort` VALUES ('3', '测试');
INSERT INTO `Sort` VALUES ('4', '测试修改');

-- ----------------------------
-- Table structure for User
-- ----------------------------
DROP TABLE IF EXISTS `User`;
CREATE TABLE `User` (
  `Uuid` varchar(255) COLLATE utf8_bin NOT NULL COMMENT 'ID',
  `Username` varchar(64) COLLATE utf8_bin NOT NULL COMMENT '账号',
  `Password` varchar(255) COLLATE utf8_bin NOT NULL COMMENT '密码',
  `Name` varchar(64) COLLATE utf8_bin DEFAULT NULL COMMENT '姓名',
  `Phone` varchar(64) COLLATE utf8_bin DEFAULT NULL COMMENT '电话',
  `Mail` varchar(64) COLLATE utf8_bin DEFAULT NULL COMMENT '邮箱',
  `Sex` varchar(4) COLLATE utf8_bin DEFAULT NULL COMMENT '性别',
  `Number` varchar(64) COLLATE utf8_bin DEFAULT NULL COMMENT '学号',
  `State` varchar(4) COLLATE utf8_bin DEFAULT 'F' COMMENT '是否校验短信',
  `Able` varchar(4) COLLATE utf8_bin DEFAULT 'T' COMMENT '是否启用'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin ROW_FORMAT=COMPACT;

-- ----------------------------
-- Records of User
-- ----------------------------
INSERT INTO `User` VALUES ('1', 'abc', '7', '第一人', '1888888888', '163@163.com', '男', '201810010', 'F', 'T');
INSERT INTO `User` VALUES ('2', 'def', '7', '第二人', '1888888888', '163@163.com', '男', '201810012', 'F', 'T');
INSERT INTO `User` VALUES ('3', 'fng', '7', '第三人', '181888888888', '163@163.com', '男', '201810013', 'F', 'T');

-- ----------------------------
-- Table structure for UserInfo
-- ----------------------------
DROP TABLE IF EXISTS `UserInfo`;
CREATE TABLE `UserInfo` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '用户ID',
  `UserName` varchar(100) NOT NULL COMMENT '用户名称',
  `PassWord` varchar(100) NOT NULL COMMENT '用户密码',
  `ActualName` varchar(100) NOT NULL COMMENT '真实姓名',
  `Phone` int(20) NOT NULL,
  `Email` varchar(255) NOT NULL COMMENT '用户邮箱（具体邮箱待定）',
  `UserImg` varchar(255) DEFAULT '../img/default.jpg' COMMENT '用户头像',
  `UserState` int(11) DEFAULT '0' COMMENT '用户状态(1.启用，0.不启用)默认0',
  `LastLoginTime` datetime DEFAULT NULL COMMENT '上次登录时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of UserInfo
-- ----------------------------
INSERT INTO `UserInfo` VALUES ('1', '用户1', '789', '798', '1836569851', '789', '../img/default.jpg', '0', null);
INSERT INTO `UserInfo` VALUES ('2', '用户2', '7', '7', '1212125469', '4', '../img/default.jpg', '0', null);
INSERT INTO `UserInfo` VALUES ('3', '用户3', '1', '1', '1010101213', '1', '../img/default.jpg', '0', '2018-10-08 11:12:42');

-- ----------------------------
-- Table structure for Works
-- ----------------------------
DROP TABLE IF EXISTS `Works`;
CREATE TABLE `Works` (
  `Id` int(12) NOT NULL AUTO_INCREMENT COMMENT '作品id',
  `Title` varchar(20) NOT NULL DEFAULT '' COMMENT '标题',
  `Content` varchar(255) NOT NULL COMMENT '内容简介',
  `FileAddress` varchar(255) DEFAULT NULL COMMENT '文件地址',
  `AuthorId` int(6) DEFAULT '0' COMMENT '作者ID',
  `ActivityId` int(10) DEFAULT NULL COMMENT '活动ID',
  `Sort` int(10) DEFAULT NULL COMMENT '作品分类',
  `AuthorName` varchar(50) DEFAULT '' COMMENT '作者姓名',
  `CreatedAt` datetime DEFAULT NULL COMMENT '创建时间（用户创建）',
  `PublishedAt` datetime DEFAULT NULL COMMENT '发布时间（管理员发布）',
  `IsDeleted` int(1) DEFAULT '0' COMMENT '是否标识已删除[1:是，0:否],默认值:0',
  `AllowShow` int(1) DEFAULT '0' COMMENT '是否允许展示[0:否,1:是],默认值:0',
  `LikesCount` bigint(20) DEFAULT '0' COMMENT '点赞量',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of Works
-- ----------------------------
INSERT INTO `Works` VALUES ('1', '更改', '更改1223', '阿萨', '1', '4', '1', '0', '2018-09-19 16:42:46', '2018-09-26 13:53:09', '0', '0', '620');
INSERT INTO `Works` VALUES ('2', '作品2', '4723', null, '2', '1', '2', '', null, '2018-09-20 05:18:55', '0', '1', '600');
INSERT INTO `Works` VALUES ('3', '作品3', '324', null, '1', '1', '2', '', null, '2011-09-26 16:19:02', '0', '0', '100');
INSERT INTO `Works` VALUES ('4', '作品4', '123', null, '2', '1', '1', '', null, '2018-09-28 16:19:07', '0', '0', '800');
INSERT INTO `Works` VALUES ('11', '', 'lk', '5', '0', null, null, '', null, null, '0', '0', '0');
