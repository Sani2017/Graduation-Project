﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Common
{
    public class UserWorkImg
    {        /// <summary>
        /// 作品id
        /// </summary>
        public int WorkId { get; set; }

        /// <summary>
        /// 作品头像
        /// </summary>
        public string WorksImg { get; set; }

    }
}
