﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;
////using JWT.Algorithms;
////using JWT.Serializers;
////using JWT;
//namespace Common.Token
//{
//    public class CommonToken
//    {
//        public static string SecretKey = "This is a private key for Server";//这个服务端加密秘钥 属于私钥
//        /// <summary>
//        /// 生成用户token
//        /// </summary>
//        /// <param name="userName">用户名</param>
//        /// <param name="pwd">密码</param>
//        /// <returns></returns>
//        public static string GetToken(string userName, string pwd)
//        {
//            Guid guid = new Guid();
//            string userInfo = userName + pwd;
//            var token = guid.ToString("N");
//            var token2 = Convert.ToBase64String(guid.ToByteArray()).TrimEnd('=');
//            var uuid = Guid.NewGuid().ToString(); // 9af7f46a-ea52-4aa3-b8c3-9fd484c2af12
//            var to3ken = Guid.NewGuid().ToString("N");

//            return token2;
//        }
//    }

//}
