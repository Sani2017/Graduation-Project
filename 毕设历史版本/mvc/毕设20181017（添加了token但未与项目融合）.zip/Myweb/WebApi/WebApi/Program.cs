﻿using Common;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http;

namespace WebApi
{
    public class Program
    {
         [Route("api/main")] 
        static void Main(string[] args)
        {
            int staffId = int.Parse(AppSettingsConfig.StaffId);
            var tokenResult = WebApiTokenHelper.GetSignToken(staffId);
            Dictionary<string, string> parames = new Dictionary<string, string>();
            parames.Add("id", "1");
            parames.Add("name", "wahaha");
            Tuple<string, string> parameters = WebApiTokenHelper.GetQueryString(parames);
            //http://localhost:14826/api/product/getproduct
            //http://localhost:14826/api/product/addProduct
            var product1 = WebApiTokenHelper.Get<ProductResultMsg>("http://localhost:6992/api/Product/getproduct", parameters.Item1, parameters.Item2, staffId);
            
            
            Product product = new Product() { Id = 1, Name = "安慕希", Count = 10, Price = 58.8 };
            var product2 = WebApiTokenHelper.Post<ProductResultMsg>("http://localhost:6992/api/Product/AddProudct", JsonConvert.SerializeObject(product), staffId);
            Console.Read();
        }


    }
}