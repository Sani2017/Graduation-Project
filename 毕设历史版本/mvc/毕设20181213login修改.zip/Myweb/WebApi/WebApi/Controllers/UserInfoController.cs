﻿using BLL;
using Models;
using Common.Constant;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Models.ModelTemplate;
using DAl.Models;
using Common;
using System.Threading.Tasks;
using System.Web.Hosting;
using System.IO;
using System.Web;

using qcloudsms_csharp;
using qcloudsms_csharp.json;
using qcloudsms_csharp.httpclient;

namespace DAl.Controllers
{
    
    public class UserInfoController : ApiController
    {
        UserInfoBLL dt = new UserInfoBLL();
        /// <summary>
        /// 获取表中所有用户信息
        /// </summary>
        /// <returns></returns>
        [AcceptVerbs("Get", "Options")]
        [FunctionView("获取表中所有用户信息", OperationType.RETRIEVE)]
        [Route("api/UserInfo/GetAllUserInfo")]

        public TMessage<List<UserInfo>> GetAllUserInfo()//List<post>JsonResult
        {
            return dt.AllUserInfor();
        }

        /// <summary>
        /// 获取表中所有用户作品
        /// </summary>
        /// <returns></returns>
        [AcceptVerbs("Get", "Options")]
        [FunctionView("获取表中所有用户以及作品", OperationType.RETRIEVE)]
        [Route("api/UserInfo/GetAllUserWorksInfo")] 
        public object GetAllUserWorksInfo(){
            return dt.AllUserWorksInfo();
        }

        /// <summary>
        /// 根据用户id获取用户信息
        /// </summary>
        /// <param name="Id">用户Id</param>
        /// <returns></returns>
        [AcceptVerbs("Get", "Options")]
        [FunctionView("根据用户id获取用户信息", OperationType.RETRIEVE)]
        [Route("api/UserInfo/GetUserInfoById")]
        public object GetUserInfoById(int Id)
        {
            return dt.GetUserInfoByID(Id);
        }
        /// <summary>
        /// 用户登录验证
        /// </summary>
        /// <param name="model">用户表传参model</param>
        /// <returns></returns>
        [AcceptVerbs("Post", "Options")]
        [FunctionView("用户登录验证", OperationType.LOGON)]
        [Route("api/UserInfo/UserLogin")]
        public TMessage<List<UserInfo>> UserLogin(UserInfoModel model)
        {

            TMessage<List<UserInfo>> mes = new TMessage<List<UserInfo>>();
            if (string.IsNullOrWhiteSpace(model.UserName) 
                || string.IsNullOrWhiteSpace(model.PassWord)) {
                mes.suc=false;
                mes.mes=ConstHelper.USERNAME_PASSWORD_EMPTY;
                return mes;
            }
            return dt.UserLogin(model.UserName, model.PassWord);
            
        }
        /// <summary>
        /// 用戶注冊
        /// </summary>
        /// <param name="model"></param>
        /// <returns>
        /// 1.注册成功就直接登录(暂定使用第一种，生成token去验证~)
        /// 2.返回登录页面再登录
        /// </returns>
        [AcceptVerbs("Post", "Options")]
        [FunctionView("用戶注冊", OperationType.OTHER)]
        [Route("api/UserInfo/AddUserInfo")]
        public object AddUserInfo(UserInfoModel model)
        {
            TMessage<UserInfo> mes = new TMessage<UserInfo>();
            if(string.IsNullOrWhiteSpace(model.UserName.Trim())
                || string.IsNullOrWhiteSpace(model.PassWord.Trim())
                || string.IsNullOrWhiteSpace(model.ActualName.Trim())
                || string.IsNullOrWhiteSpace(model.UserPhone.ToString().Trim())
                || string.IsNullOrWhiteSpace(model.Email.Trim())
                || string.IsNullOrWhiteSpace(model.UserImg.Trim()))
            {
                mes.suc = false;
                mes.mes = ConstHelper.NOT_NULL_ELEMENT_CONTENT;
                return mes;
            }
            return dt.AddUserInfo(model);
        }
        /// <summary>
        /// 判断用戶名是否重复
        /// </summary>
        /// <param name="UserName">查询用的类型名称</param>
        /// <returns></returns>
        [AcceptVerbs("Post", "Options")]
        [FunctionView("判断用戶名是否重复", OperationType.RETRIEVE)]
        [Route("api/UserInfo/SeleUserName")]
        public bool SeleUserName(string userName)
        {
            return dt.SeleUserName(userName);
        }
        /// <summary>
        /// 判断📫是否重复
        /// </summary>
        /// <param name="email">查询用的类型名称</param>
        /// <returns></returns>
        [AcceptVerbs("Post", "Options")]
        [FunctionView("判断📫是否重复", OperationType.RETRIEVE)]
        [Route("api/UserInfo/SeleEmail")]
        public bool SeleEmail(string email)
        {
            return dt.SeleEmail(email);
        }
        /// <summary>
        /// 判断手機號是否重复
        /// </summary>
        /// <param name="PhoneNumber">查询用的类型名称</param>
        /// <returns></returns>
        [AcceptVerbs("Post", "Options")]
        [FunctionView("判断手機號是否重复", OperationType.RETRIEVE)]
        [Route("api/UserInfo/SelePhoneNumber")]
        public bool SelePhoneNumber(string phoneNumber)
        {
            return dt.SelePhoneNumber(phoneNumber);
        }
        //追加郵箱,手機驗證，與密碼重置等功能誒喲！！
//-------------------------------------------------------------------        
     
        /// <summary>
        /// 邮箱内容以及配置的编辑
        /// 邮箱发生内容样式还要完善
        /// </summary>
        /// <param name="userName">用户姓名</param>
        /// <param name="userEmali">用户邮箱</param>
        /// <param name="smtpName">用户邮箱后缀如：163.com，qq.com</param>
        [AcceptVerbs("get", "Options")]
        [FunctionView("邮箱内容以及配置的编辑", OperationType.RETRIEVE)]
        [Route("api/UserInfo/EmailContent")]
        public object EmailContent(string userName, string userEmali)//, string smtpName)
        {
            return dt.EmailContent(userName, userEmali);//, smtpName);
        }
        /// <summary>
        /// 邮箱注册链接缓存验证。
        /// </summary>
        /// <param name="userName">用户名</param>
        /// <param name="validataCode">用户验证随机验证码</param>
        /// <returns></returns>
        [AcceptVerbs("get", "Options")]
        [FunctionView("邮箱注册链接缓存验证", OperationType.UPDATE)]
        [Route("api/UserInfo/EmailVerify")]
        public object EmailVerify(string userName, string validataCode)
        {
            return dt.EmailVerify(userName, validataCode);
        }

        /// <summary>
        /// 邮箱重置密码链接缓存验证。
        /// </summary>
        /// <param name="userName">用户名</param>
        /// <param name="validataCode">用户验证随机验证码</param>
        /// <returns></returns>
        [AcceptVerbs("get", "Options")]
        [FunctionView("邮箱注册链接缓存验证", OperationType.RETRIEVE)]
        [Route("api/UserInfo/EmailVerifyPassword")]
        public object EmailVerifyPassword(string userName, string validataCode)
        {
            return dt.EmailVerifyPassword(userName, validataCode);
        }
        /// <summary>
        /// 重置密码
        /// 要通过密码缓存验证true才能出现密码框
        /// 页面不跳转，从新渲染DOM
        /// </summary>
        /// <returns></returns>
        [AcceptVerbs("post", "Options")]
        [FunctionView("重置密码", OperationType.UPDATE)]
        [Route("api/UserInfo/ResetUserPassword")]
        public object ResetUserPassword(UserInfoModel model) {
            return dt.ResetUserPassword(model.UserName, model.PassWord);
        }
        /// <summary>
        /// 安全退出
        /// </summary>
        public object SafetyExit(string userName) {
            return dt.SafetyExitBll(userName);
        }
        /// <summary>
        /// 发送短信测试版
        /// </summary>
        [AcceptVerbs("post", "Options")]
        [Route("api/UserInfo/PutSms")]
        public void PutSms(string[] phoneNumbers) {
            SmsHelper sms = new SmsHelper();　　//短信发送帮助类
            sms.PutSms(phoneNumbers);
        }
        //public void PutSms(, string random)
        //{
        //    SmsHelper.PutSms(phoneNumbers, random);

        //}
    }
}
