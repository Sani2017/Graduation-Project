﻿using Common;
using DAL;
using Models.ModelTemplate;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace BLL
{
    public class UserInfoBLL
    {
        UserInfoDAL dt = new UserInfoDAL();
        /// <summary>
        /// 获取所有用户信息BLL
        /// </summary>
        /// <returns></returns>
        public TMessage<List<UserInfo>> AllUserInfor() // JsonResult
        {
            return dt.GetUserInfo();
        }

        /// <summary>
        /// 获取所有用户以及作品信息BLL
        /// </summary>
        /// <returns></returns>
        public object AllUserWorksInfo()
        {
            return dt.GetWorksInfo();
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="Id"></param>
        /// <returns></returns>
        public TMessage<UserInfo> GetUserInfoByID(int Id)
        {
            return dt.GetUserInfoByID(Id);
        }
        /// <summary>
        /// 用户登录验证BLL
        /// </summary>
        /// <param name="userName">用户名</param>
        /// <param name="pwd">密码</param>
        /// <returns></returns>
        public TMessage<List<UserInfo>> UserLogin(string userName, string pwd)
        {
            return dt.UserLogin(userName, pwd);
        }
        /// <summary>
        /// 用戶注冊BLL
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public object AddUserInfo(UserInfoModel model)
        {
            return dt.AddUserInfo(model);
        }
        /// <summary>
        /// 判断用戶名是否重复BLL
        /// </summary>
        /// <param name="UserName">查询用的类型名称</param>
        /// <returns></returns>
        public bool SeleUserName(string userName)
        {
            return dt.SeleUserName(userName);
        }
        /// <summary>
        /// 判断📫是否重复BLL
        /// </summary>
        /// <param name="email">查询用的类型名称</param>
        /// <returns></returns>
        public bool SeleEmail(string email)
        {
            return dt.SeleEmail(email);
        }
        /// <summary>
        /// 判断手機號是否重复BLL
        /// </summary>
        /// <param name="PhoneNumber">查询用的类型名称</param>
        /// <returns></returns>
        public bool SelePhoneNumber(string phoneNumber)
        {
            return dt.SelePhoneNumber(phoneNumber);
        }

        /// <summary>
        /// 邮箱内容以及配置的编辑Bll
        /// </summary>
        /// <param name="userName">用户姓名</param>
        /// <param name="userEmali">用户邮箱</param>
        /// <param name="smtpName">用户邮箱后缀如：163.com，qq.com</param>
        public object EmailContent(string userName, string userEmali)//, string smtpName)
        {
            return dt.EmailContent(userName, userEmali);//, smtpName);
        }
        /// <summary>
        /// 邮箱注册，链接缓存验证Bll
        /// </summary>
        /// <param name="userName">用户名</param>
        /// <param name="validataCode">用户验证随机验证码</param>
        /// <returns></returns>
        public object EmailVerify(string userName, string validataCode)
        {
            return dt.EmailVerify(userName, validataCode);
        }
        /// <summary>
        /// 邮箱密码重置链接缓存验证Bll
        /// </summary>
        /// <param name="userName">用户名</param>
        /// <param name="validataCode">用户验证随机验证码</param>
        /// <returns></returns>
        public object EmailVerifyPassword(string userName, string validataCode)
        {
            return dt.EmailVerifyPassword(userName, validataCode);
        }
        /// <summary>
        /// 重置密码BLL
        /// </summary>
        /// <returns></returns>
        public object ResetUserPassword(string userName, string newPwd)
        {
            return dt.ResetUserPassword(userName,newPwd);
        }
        /// <summary>
        /// 安全退出Bll
        /// </summary>
        public object SafetyExitBll(string userName)
        {
            return dt.SafetyExit(userName);
        }

    }
}
