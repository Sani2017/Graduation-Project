﻿using Common;
using Models;
using Models.ModelTemplate;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace DAL
{
    public  class OnlineDAL
    {
        SqlSugarClient db;
        /// <summary>
        /// 与数据库帮助类关联
        /// </summary>
        public OnlineDAL() 
        {
            db = SqlSugarClientHelper.SqlSugarDB();
        }

                //这个接口废弃了，使用ReplyDAL的GetReplyInfoByOnlineId。

        /// <summary>
        /// 根据留言地点的id查询留言信息与条数
        /// </summary>
        /// <param name="placeId"></param>
        /// <returns></returns>
        ///         //关于留言回复的整体输出功能有大问题，从长计议
        public object GetOnlineInfoByPlaceId(int placeId)
        {
            TMessage<List<Online>> mes = new TMessage<List<Online>>();
            var getAll = db.Queryable<Online, UserInfo, Reply>
                ((ol, ui, re) => new object[]{
                  //  JoinType.Left,ol.Uid==ui.Id,
                  JoinType.Left,re.RUid==ui.Id,
                  JoinType.Left,ol.Id==re.OnlineId
                })//uid未被發現，問題待解決
                   .OrderBy(ol => ol.Creatime, OrderByType.Desc)//活动发布时间是顺序
                   .Where(ol => ol.PlaceId == placeId)
                   .Select((ol, ui, re) => new
                   {
                       ui.UserImg,
                       ui.UserName,
                       ol.OnlineContent,
                       ol.Creatime,
                       ol.LikesCount,
                       re.Recontent,
                       re.RUid
                   }).ToList();//.ToSql();//
            //if (getAll.Count < 1)
            //{
            //    mes.suc = false;
            //    mes.mes = ConstHelper.ONLINE_ISNULL;
            //    return mes;
            //}
            //else {
            return getAll.GroupBy(ol => ol.UserName);//
            //至于有多少条留言就在前端看循环输出几次，就有几条。哈哈
            //}
            //TMessage<List<OnlineReturnModel>> mes = new TMessage<List<OnlineReturnModel>>();
            //按条件查询条数
            //var sum = db.Queryable<Online>().Where(it => it.PlaceId == placeId).Sum(it => it.PlaceId);
            //if(sum<1){
            //    mes.suc = false;
            //    mes.mes = ConstHelper.ONLINE_ISNULL;
            //}
            //else { //要多表查询通过uid查询用户信息

            //    List<OnlineReturnModel> ret = new List<OnlineReturnModel>();
            //    //ret = getAll;
            //    //OnlineReturnModel model=new OnlineReturnModel();

            //    //for (getAll ; index <= sum; index++)
            //    //{
            //    //    model.Content=
            //    //}
            //    //mes.suc = true;
            //    //mes.mes = sum.ToString();
            //    //mes.extra = getAll;
            //    return getAll.Count;
            //}
            //db.Queryable<Student>().Where(it => SqlFunc.ToLower(it.Name) == SqlFunc.ToLower("JACK")).ToList();
            //return mes;
        }
        /// <summary>
        /// 添加留言信息
        /// </summary>
        /// <returns></returns>
        public object AddOnlineInfo(OnlineModel model) {
            TMessage<Online> mes = new TMessage<Online>();
            Online online = new Online();
            online.PlaceId = model.PlaceId;
            online.Uid = model.Uid;
            online.OnlineContent = model.OnlineContent;
            online.Creatime = DateTime.Now.ToLocalTime();
            var addOnline = db.Insertable(online).ExecuteCommand();
            if (addOnline < 1)
            {
                mes.suc = false;
                mes.mes = ConstHelper.INSERT_MODEL_ERROR;
            }
            else {
                mes.suc = true;
                mes.mes = ConstHelper.INSERT_MODEL_SUCCESS + addOnline + "条";
            }
            return mes;
        }
        /// <summary>
        /// 增加留言的点赞量
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public object UpdatOnlineLikes(int id)
        {
            TMessage<Online> mes = new TMessage<Online>();

            //留言赞数+1
            var updateLikes = db.Updateable<Online>()
                .UpdateColumns(it => new Online() { LikesCount = it.LikesCount + 1 })
                .Where(it => it.Id == id).ExecuteCommand();
            if (updateLikes<1) {
                mes.suc = false;
                mes.mes = ConstHelper.UPDATE_MODEL_ERROR;
            }else{
                mes.suc=true;
                mes.mes=ConstHelper.UPDATE_MODEL_SUCCESS;
            }
            return mes;
        }
        /// <summary>
        /// 通过留言表id删除留言表与回复表的相关内容
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public object DelOnlineInfo(int id) {
            TMessage<Online> mes = new TMessage<Online>();

            var t5 = db.Deleteable<Online>().Where(it => it.Id == id).ExecuteCommand();//删除留言表的相关id
            if(t5<1){
                mes.suc = false;
                mes.mes = ConstHelper.DELETE_MODEL_ERROR;
            }else{
                db.Deleteable<Reply>().Where(it => it.OnlineId == id).ExecuteCommand();//删除与留言相关的回复
                mes.suc=true;
                mes.mes = ConstHelper.DELETE_MODEL_SUCCESS;
            }
            return mes;
        }
    }
}
