﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Common
{
    /// <summary>
    /// 用于类似首页作品列表输出
    /// </summary>
    public class IndexWorksListModel
    {
        public string WorkImg{get;set;}//作品封面
        public int WorksId {get;set;} //作品id
        public string WorksTitle {get;set;}//标题
        public int LikesCount {get;set;}//点赞量
        public DateTime PublishedAt {get;set;}//发布时间
        public int UserId {get;set;}//用户id
        public string UserName {get;set;}//用户名
        public string UserImg {get;set;}//用户头像
        public int Sort { get; set; }//作品分类

    }
}
