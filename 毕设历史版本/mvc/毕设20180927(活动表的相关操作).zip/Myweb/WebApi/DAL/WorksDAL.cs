﻿using Common;
using Common.CommonModel;
using Models;
using Models.ModelTemplate;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebApi.Models;
namespace DAL
{

    public class WorksDAL
    {
        /// <summary>
        /// 关于作品表的sql操作
        /// </summary>
        SqlSugarClient db;
        public WorksDAL()
        {
            db = SqlSugarClientHelper.SqlSugarDB();
        }
        /// <summary>
        /// 查询所有作品表内容sql
        /// </summary>
        /// <returns></returns>
        public object GetWorksInfo()
        {

            var getAll = db.Queryable<Works>().ToList();
            Console.WriteLine(getAll);
            return getAll;
        }
        //where（it=>it.aa="某作者"）.count()
        /// <summary>
        /// 修改作品表内容sql
        /// </summary>
        /// <returns>object</returns>
        public TMessage<Works> UpdateWorksInfo(UpdateWorkModel model)
        {
            TMessage<Works> mes = new TMessage<Works>();

            //4.指定对象更新，需要先获取在修改
            Works work = db.Queryable<Works>()
                .Where(q => q.Id == model.Id)
                .First();
            Works NewWorks = new Works();
            //实体类与公共类比较
            if (!work.AllowShow.Equals(model.AllowShow)) { work.AllowShow = model.AllowShow; }//是否允许展示
            if (!work.IsDeleted.Equals(model.IsDeleted)) { work.IsDeleted = model.IsDeleted; }//是否标识已删除
            if (!work.Sort.Equals(model.Sort)) { work.Sort = model.Sort; }//作品分类
            if (!work.ActivityId.Equals(model.ActivityId)) { work.ActivityId = model.ActivityId; }//活动ID
            if (!work.FileAddress.Equals(model.FileAddress)) { work.FileAddress = model.FileAddress; }//文件地址
            if (!work.Content.Equals(model.Content)) { work.Content = model.Content; }//内容简介
            if (!work.Title.Equals(model.Title)) { work.Title = model.Title; }//标题
            work.PublishedAt = DateTime.Now.ToLocalTime();//发布时间（管理员发布）
            work.CreatedAt = work.CreatedAt;//创建时间（用户创建）
            var result4 = db.Updateable(work).ExecuteCommand();//db.Updateable(work);//.ExecuteCommand(); 
            //Console.WriteLine(result4);
            if (result4 == 1)
            {
                mes.suc = true;
                mes.mes = "修改成功";
            }
            else {
                mes.suc = false;
                mes.mes = "修改失败，请检查";
            }
            return mes;//result4;
        }

         ///<summary>
         ///根据作者Id去获取相应的作品数量sql
         ///</summary>
         ///<returns></returns>
        public object GetWorksInfoByAuthorId(int AuthorId)
        {
            TMessage<Works> mes = new TMessage<Works>();
            int getAll = db.Queryable<Works>()
                .Where(wk => wk.AuthorId == AuthorId)
                .Count();
            mes.suc = true;
            mes.mes = getAll.ToString();
            return mes;
        }
    }
}
