﻿using Models;
using Models.ModelTemplate;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;
 
namespace DAL
{
        /// <summary>
        /// 关于用户信息表的sql操作
        /// </summary>
    public class UserInforDAL
    {
        SqlSugarClient db;
        /// <summary>
        /// 与数据库帮助类关联
        /// </summary>
        public UserInforDAL() 
        {
            db = SqlSugarClientHelper.SqlSugarDB();
        }
        /// <summary>
        /// 获取所有用户信息
        /// </summary>
        /// <returns></returns>
        public List<UserInfo> GetUserInfo()//JsonResult
        {

            var getAll = db.Queryable<UserInfo>().ToList();
            return  getAll;
        }

        /// <summary>
        /// 获取所有用户以及作品信息
        /// </summary>
        /// <returns>用户表/作品表查询</returns>
        public object GetWorksInfo() {
                var AllList = db.Queryable<Works, UserInfo>((wk, ui) => new object[] { JoinType.Right, ui.Id == wk.AuthorId })
                // .GroupBy(ui => new { ui.Id, ui.UserName })
                .OrderBy((wk, ui) => ui.Id, OrderByType.Asc)//id是顺序
                .OrderBy((wk) => wk.PublishedAt, OrderByType.Desc)//发布时间是倒叙
                .Select(( wk,ui) => new
                {
                    UserId = ui.Id,
                    UserName = ui.UserName,
                    WorksId = wk.Id,
                    Title = wk.Title,
                    Content = wk.Content,
                    Sort = wk.Sort,
                    AllowShow = wk.AllowShow,
                    LikesCount = wk.LikesCount,
                    CreatedAt=wk.CreatedAt,
                    PublishedAt = wk.PublishedAt

                })//.ToSql();
                   .ToList();

            return AllList.GroupBy(ui => ui.UserName);//分组，大集合嵌套小集合

        }

    }
}
