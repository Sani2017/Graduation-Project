﻿using Models.ModelTemplate;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class SortDAL
    {
        SqlSugarClient db;
        public SortDAL() {
            db = SqlSugarClientHelper.SqlSugarDB();
        }
        /// <summary>
        /// 查询所有类别表内容
        /// </summary>
        /// <returns></returns>
        public object GetSort() {
            var getAll = db.Queryable<Sort>().ToList();
            return getAll;
        }
    }
}
