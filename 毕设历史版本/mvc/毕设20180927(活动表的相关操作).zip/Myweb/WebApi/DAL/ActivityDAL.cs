﻿using Common;
using Common.CommonModel;
using Models;
using Models.ModelTemplate;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebApi.Models;

namespace DAL
{
    public class ActivityDAL
    {
        /// <summary>
        /// 关于活动表的sql操作
        /// </summary>
        SqlSugarClient db;
        public ActivityDAL(){
            db=SqlSugarClientHelper.SqlSugarDB();
        }
        /// <summary>
        /// 增加活动信息sql
        /// </summary>
        /// <param name="model">活动表传参的model类</param>
        /// <returns></returns>
        public TMessage<Activity> AddActivity(ActivityModel model)
        {
            //也可以批量插入
            TMessage<Activity> mes = new TMessage<Activity>();
            //model.ActivityContent
            // model.ActivityName
            Activity activity = new Activity();
            activity.ActivityContent = model.ActivityContent;
            activity.ActivityName = model.ActivityName;
            var t4 = //db.Insertable(model).ExecuteCommand(); 
                db.Insertable(activity).InsertColumns(it => new { it.ActivityName, it.ActivityContent })
                .ExecuteCommand(); //.ToSql();
            if (t4 >= 1)
            {
                mes.suc = true;
                mes.mes = "新增活动" + t4 + "条";
            }
            else {
                mes.suc = false;
                mes.mes = "新增活动失败";
            }
            return mes;//result4;.ExecuteReturnIdentity()

        }
       /// <summary>
       /// 根据id删除活动
       /// </summary>
       /// <param name="Id">活动Id</param>
       /// <returns></returns>
        public TMessage<Activity> DeleActivity(int Id){
            TMessage<Activity> mes = new TMessage<Activity>();

            bool SeleTF = SeleActivityById(Id);
            if (SeleTF)
            {
                var t0 = //db.Deleteable<Activity>().Where(new Activity() { Id = Id }).ExecuteCommand();
                    db.Deleteable<Activity>(Id).ExecuteCommand();//.ToSql();//
                mes.suc = true;
                mes.mes = "删除成功";
            }
            else {
                mes.suc = false;
                mes.mes = "为查询到所要删除的内容";
            }
            return mes;
        }
        /// <summary>
        /// 根据id修改活动
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public TMessage<Activity> UpdateActivity(ActivityModel model) {
            //        public TMessage<Activity> AddActivity(ActivityModel model)

            TMessage<Activity> mes = new TMessage<Activity>();

            bool SeleTF = SeleActivityById(model.Id);
            if (SeleTF)//判断是否存在
            {
                //4.指定对象更新，需要先获取在修改
                Activity activity = db.Queryable<Activity>()
                .Where(q => q.Id == model.Id)
                .First();
                if (activity.ActivityContent.Equals(model.ActivityContent)//判断前端是否有修改
                    && activity.ActivityName.Equals(model.ActivityName)
                    && activity.ActivityState.Equals(model.ActivityState))
                {
                    mes.suc = false;
                    mes.mes = "信息未修改";
                    return mes;
                }
                else {//赋值修改内容（应该是逐条修改，现在是全部修改，可改进！！）
                    activity.ActivityContent = model.ActivityContent;
                    activity.ActivityName = model.ActivityName;
                    activity.ActivityState = model.ActivityState;
                    var result4 = db.Updateable(activity).ExecuteCommand();//.ToSql();//db.Updateable(work);//.ExecuteCommand(); 
                    mes.suc = true;
                    mes.mes = "修改成功";
                }
            }
            else {
                mes.suc = false;
                mes.mes = "为查询到所要修改的内容";
            }
            return mes;
        }

        /// <summary>
        /// 获取所有活动信息
        /// </summary>
        /// <returns></returns>
        public List<Activity> GetActivityInfo() {
            var getAll = db.Queryable<Activity>().ToList();
            return getAll;
        }
        /// <summary>
        /// 查询活动表相关记录
        /// </summary>
        /// <param name="SelectName">查询的名称</param>
        /// <returns></returns>
        public List<Activity> GetSelectActivity(string SelectName) {
            var c1 = db.Queryable<Activity>().Where(c => c.ActivityName.Contains(SelectName)).ToList();
            foreach (Activity i in c1)
            {
                Console.WriteLine("{0}  {1}  {2}  {3}", i.Id, i.ActivityName, i.ActivityContent, i.ActivityState);
            }
            return c1;

        }

        /// <summary>
        /// 根据ID查询活动是否存在
        /// </summary>
        /// <param name="Id"></param>
        public bool SeleActivityById(int Id) {
            var getByWhere = db.Queryable<Activity>().Where(it => it.Id == Id).Any();//.ToList();
            return getByWhere;
            
        }
    }
}
