﻿using BLL;
using Common.Constant;
using Models;
using Models.ModelTemplate;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http; 
using System.Web.Http;


namespace WebApi.Controllers
{
    
    public class UserInfoController : ApiController
    {
        UserInforBLL dt = new UserInforBLL();
        /// <summary>
        /// 获取表中所有用户信息
        /// </summary>
        /// <returns></returns>
        [AcceptVerbs("Get", "Options")]
        [FunctionView("获取表中所有用户信息", OperationType.RETRIEVE)]
        [Route("api/UserInfo/GetAllUserInfo")] 

        public List<UserInfo> GetAllUserInfo()//List<post>JsonResult
        {
            return dt.AllUserInfor();
        }

        /// <summary>
        /// 获取表中所有用户作品
        /// </summary>
        /// <returns></returns>
        [AcceptVerbs("Get", "Options")]
        [FunctionView("获取表中所有用户以及作品", OperationType.RETRIEVE)]
        [Route("api/UserInfo/GetAllUserWorksInfo")] 
        public object GetAllUserWorksInfo(){
            return dt.AllUserWorksInfo();
        }
        
        //AllUserWorksInfo
        
        //public object GetAllUserWorksInfo()//List<post>JsonResult
        //{
        //    return dt.AllUserWorksInfo();

        //}
    }
}
