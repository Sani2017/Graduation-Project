﻿using BLL;
using Models;
using Common.Constant;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace WebApi.Controllers
{
    public class SortController : ApiController
    {
       SortBLL dt=new SortBLL();
        /// <summary>
        /// 获取表中所有分类信息
        /// </summary>
        /// <returns></returns>
       [AcceptVerbs("Get", "Options")]
       [FunctionView("获取表中所有分类信息", OperationType.RETRIEVE)]
       [Route("api/UserInfo/GetAllSort")] 

       public object GetAllSort() {
           return dt.AllSort();
       }
    }
}
