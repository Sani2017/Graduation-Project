﻿using BLL;
using Models;
using Common.Constant;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Models.ModelTemplate;
using WebApi.Models;
using Common.CommonModel;
using Common;

namespace WebApi.Controllers
{
    public class ActivityController : ApiController
    {
        ActivityBLL dt = new ActivityBLL();
        /// <summary>
        /// 增加活动信息
        /// </summary>
        /// <returns></returns>
        [AcceptVerbs("post", "Options")]
        [FunctionView("增加活动信息", OperationType.CREATE)]
        [Route("api/Activity/AddActivityInfo")]
        public TMessage<Activity> AddActivityInfo(ActivityModel model)
        {
            TMessage<Activity> mes = new TMessage<Activity>();
            if(string.IsNullOrEmpty(model.ActivityName)
             ||string.IsNullOrEmpty(model.ActivityContent)){
                mes.suc=false;
                mes.mes="所传值不能为空";
                return mes;
            }
            return dt.AddActivity(model);
           
        }
        /// <summary>
        /// 删除活动信息
        /// </summary>
        /// <param name="model">删除活动所用的Id</param>
        /// <returns></returns>
        [AcceptVerbs("post", "Options")]
        [FunctionView("删除活动信息", OperationType.DELETE)]
        [Route("api/Activity/DeleActivityInfo")]
        public TMessage<Activity> DeleActivityInfo(ActivityModel model)
        {
            TMessage<Activity> mes = new TMessage<Activity>();
            if (string.IsNullOrEmpty(model.Id.ToString()))
            {
                mes.suc = false;
                mes.mes = "所传值不能为空";
                return mes;
            }
            return dt.DeleActivity(model.Id);
        }
        /// <summary>
        /// 修改活动信息
        /// </summary>
        /// <returns></returns>
        [AcceptVerbs("post", "Options")]
        [FunctionView("修改活动信息", OperationType.UPDATE)]
        [Route("api/Activity/UpdateActivityInfo")]
        public TMessage<Activity> UpdateActivityInfo(ActivityModel model)
        {
            TMessage<Activity> mes = new TMessage<Activity>();
            if (string.IsNullOrEmpty(model.ActivityName)
                 || string.IsNullOrEmpty(model.ActivityContent))
            {
                mes.suc = false;
                mes.mes = "所传值不能为空";
                return mes;
            }
            return dt.UpdateActivity(model);
        }
        /// <summary>
        /// 查询所有的活动表内容
        /// </summary>
        /// <returns></returns>
        [AcceptVerbs("get", "Options")]
        [FunctionView("查询所有的活动表内容", OperationType.RETRIEVE)]
        [Route("api/Activity/GetAllActivityInfo")]
        public List<Activity> GetAllActivityInfo()
        {
            return dt.AllActivityInfo();
        }
        /// <summary>
        /// 查询活动表相关记录
        /// </summary>
        /// <param name="SelectName">查询的名称</param>
        /// <returns></returns>
        [AcceptVerbs("get", "Options")]
        [FunctionView("查询活动表相关记录", OperationType.RETRIEVE)]
        [Route("api/Activity/GetSelectActivityInfo")]
        public List<Activity> GetSelectActivityInfo(string SelectName)
        {
            return dt.SelectActivityInfo(SelectName);
        }

    }
}
