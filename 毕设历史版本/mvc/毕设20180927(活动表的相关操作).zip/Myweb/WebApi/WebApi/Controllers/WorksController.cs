﻿using BLL;
using Models;
using Common.Constant;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Models.ModelTemplate;
using WebApi.Models;
using Common.CommonModel;
using Common;

namespace WebApi.Controllers
{
    public class WorksController : ApiController
    {
        WorksBLL dt = new WorksBLL();
        /// <summary>
        /// 获取表中所有作品信息
        /// </summary>
        /// <returns></returns>OperationType.RETRIEVE
        [AcceptVerbs("Get", "Options")]
        [FunctionView("获取表中所有作品信息",OperationType.RETRIEVE)]
        [Route("api/Works/GetAllWorks")] 
        public object GetAllWorks()//List<post>
        {
            return dt.AllWorks();
        }
        /// <summary>
        /// 修改作品表内容
        /// </summary>
        /// <returns>11个内容要全部上传，数据层会判断该是否更改</returns>
        [AcceptVerbs("post", "Options")]
        [FunctionView("修改作品表内容", OperationType.UPDATE)]
        [Route("api/Works/UpdateAllWorks")]
        public TMessage<Works> UpdateAllWorks(UpdateWorkModel model)
        {
            //var asd=true;添加判断model中的值是否为空
            TMessage<Works> mes = new TMessage<Works>();
            if (string.IsNullOrEmpty(model.Id.ToString())){//所有传参不能为空
                mes.suc=false;
                mes.mes="Id不能为空";
                return mes;
            }
            if(model==null){
                mes.suc = false;
                mes.mes = "传参不能为空";
                return mes;
            }
            return dt.UpdateWorksAll(model);
        }
        /// <summary>
        /// 根据作者Id去获取相应的作品数量
        /// </summary>
        /// <returns></returns>OperationType.RETRIEVE
        [AcceptVerbs("Get", "Options")]
        [FunctionView("根据作者Id获取表中作品数量", OperationType.RETRIEVE)]
        [Route("api/Works/GetWorksInfoByAuthorId")]
        public object GetWorksInfoByAuthorId(int AuthorId)
        {
            return dt.GetAllWorksInfoByAuthorId(AuthorId);
        }
        /// <summary>
        /// 修改作品的状态(IsDeleted,是否标识已删除;AllowShow是否允许展示)
        /// </summary>
        //[AcceptVerbs("Get", "Options")]
        //[FunctionView("根据作者Id获取表中作品数量", OperationType.RETRIEVE)]
        //[Route("api/Works/UpdateWorkStatus")]
        //public TMessage<Works> UpdateWorkStatus {
        //    //我还要考虑一下（软删除 +  定时任务）
        //}
    }
}
