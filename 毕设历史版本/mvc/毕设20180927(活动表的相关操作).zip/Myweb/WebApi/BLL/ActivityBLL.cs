﻿using DAL;
using Models;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Common.CommonModel;
using Common;
using Models.ModelTemplate;

namespace BLL
{
    public class ActivityBLL
    {
        ActivityDAL dt = new ActivityDAL();
        /// <summary>
        /// 新增活动BLL层
        /// </summary>
        /// <returns></returns>
        public TMessage<Activity> AddActivity(ActivityModel model)
        {
            return dt.AddActivity(model);
        }
        /// <summary>
        /// 删除活动BLL层
        /// </summary>
        /// <param name="Id">删除所用的Id</param>
        /// <returns></returns>
        public TMessage<Activity> DeleActivity(int Id) {
            return dt.DeleActivity(Id);
        }
        /// <summary>
        /// 修改活动BLL层
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public TMessage<Activity> UpdateActivity(ActivityModel model)
        {
            return dt.UpdateActivity(model);
        }
        /// <summary>
        /// 获取所有活动信息BLL层
        /// </summary>
        /// <returns></returns>
        public List<Activity> AllActivityInfo() {
            return dt.GetActivityInfo();
        }
        /// <summary>
        /// 查询活动表相关记录BLL层
        /// </summary>
        /// <param name="SelectName">查询的名称</param>
        /// <returns></returns>
        public List<Activity> SelectActivityInfo(string SelectName)
        {

            return dt.GetSelectActivity(SelectName);
        }
    }
}
