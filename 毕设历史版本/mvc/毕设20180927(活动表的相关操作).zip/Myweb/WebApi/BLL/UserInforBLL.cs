﻿using DAL;
using Models.ModelTemplate;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace BLL
{
    public class UserInforBLL
    {
        UserInforDAL dt = new UserInforDAL();
        /// <summary>
        /// 获取所有用户信息
        /// </summary>
        /// <returns></returns>
        public List<UserInfo> AllUserInfor() // JsonResult
        {
            return dt.GetUserInfo();
        }

        /// <summary>
        /// 获取所有用户以及作品信息
        /// </summary>
        /// <returns></returns>
        public object AllUserWorksInfo() {
            return dt.GetWorksInfo();
        }
    }
}
