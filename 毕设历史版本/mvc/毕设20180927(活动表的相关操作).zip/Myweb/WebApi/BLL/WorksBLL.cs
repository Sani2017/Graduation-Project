﻿using DAL;
using Models;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Common.CommonModel;
using Common;
using Models.ModelTemplate;


namespace BLL
{
    public class WorksBLL
    {
        WorksDAL dt = new WorksDAL();
        /// <summary>
        /// 获取所有信息BLL
        /// </summary>
        /// <returns></returns>
        public object AllWorks()
        {
            return dt.GetWorksInfo();
        }
        /// <summary>
        /// 可修改作品表中所有信息BLL
        /// </summary>
        /// <returns>object</returns>
        public TMessage<Works> UpdateWorksAll(UpdateWorkModel model)
        {
            return dt.UpdateWorksInfo(model);
        }
        public object GetAllWorksInfoByAuthorId(int AuthorId)
        {
            return dt.GetWorksInfoByAuthorId(AuthorId);
        }


    }
}
