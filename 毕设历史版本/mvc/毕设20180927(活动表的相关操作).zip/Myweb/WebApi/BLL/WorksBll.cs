﻿using DAL;
using Models;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace BLL
{
    public class WorksBLL
    {
        WorksDAL dt = new WorksDAL();
        public object AllWorks()
        {
            return dt.GetWorksInfo();
        }
    }
}
