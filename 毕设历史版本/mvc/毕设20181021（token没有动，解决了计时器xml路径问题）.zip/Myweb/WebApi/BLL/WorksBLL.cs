﻿using DAL;
using Models;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Common;
using Models.ModelTemplate;


namespace BLL
{
    public class WorksBLL
    {
        WorksDAL dt = new WorksDAL();
        /// <summary>
        /// 获取所有信息BLL
        /// </summary>
        /// <returns></returns>
        public TMessage<List<Works>> AllWorks()
        {
            return dt.GetWorksInfo();
        }
        /// <summary>
        /// 可修改作品表中所有信息BLL
        /// </summary>
        /// <returns>object</returns>
        public TMessage<Works> UpdateWorksAll(UpdateWorkModel model)
        {
            return dt.UpdateWorksInfo(model);
        }
        /// <summary>
        /// 根据作者Id去获取相应的作品数量BLL
        /// </summary>
        /// <param name="AuthorId">作者Id</param>
        /// <returns></returns>
        public object GetAllWorksInfoByAuthorId(int AuthorId)
        {
            return dt.GetWorksInfoByAuthorId(AuthorId);
        }
        /// <summary>
        /// 获取点赞榜排名与用户表关联BLL
        /// </summary>
        /// <returns></returns>
        public object GetAllWorksLikesCount() {
            return dt.GetAllWorksLikesCountInfo();
        }
        /// <summary>
        /// 批量删除作品表信息BLL
        /// </summary>
        /// <param name="deleBatchById"></param>
        /// <returns></returns>
        public object DeleBatchWorksInfo(int[] deleBatchById) {
            return dt.DeleBatchWorksInfo(deleBatchById);
        }
        public object UpdateWorkIsDeleted(int[] Id)
        {
            return dt.UpdateWorkIsDeleted(Id);
        }

        public object DelWorkInfoByIsDeleted() {
            return dt.DelWorkInfoByIsDeleted();
        }
    }
}
