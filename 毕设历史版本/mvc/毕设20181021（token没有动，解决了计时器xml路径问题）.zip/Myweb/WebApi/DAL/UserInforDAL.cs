﻿using Common;
using Models;
using Models.ModelTemplate;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;
 
namespace DAL
{
        /// <summary>
        /// 关于用户信息表的sql操作
        /// </summary>
    public class UserInforDAL
    {
        SqlSugarClient db;
        /// <summary>
        /// 与数据库帮助类关联
        /// </summary>
        public UserInforDAL() 
        {
            db = SqlSugarClientHelper.SqlSugarDB();
        }
        /// <summary>
        /// 获取所有用户信息
        /// </summary>
        /// <returns></returns>
        public List<UserInfo> GetUserInfo()//JsonResult
        {

            var getAll = db.Queryable<UserInfo>().ToList();
            return  getAll;
        }

        /// <summary>
        /// 获取所有用户以及作品信息
        /// </summary>
        /// <returns>用户表/作品表查询</returns>
        public object GetWorksInfo() {
            var AllList = db.Queryable<Works, UserInfo>((wk, ui) => new object[] { JoinType.Right, ui.Id == wk.AuthorId })
                // .GroupBy(ui => new { ui.Id, ui.UserName })
                .OrderBy((wk, ui) => ui.Id, OrderByType.Asc)//id是顺序
                .OrderBy((wk) => wk.PublishedAt, OrderByType.Desc)//发布时间是倒叙
                .Select(( wk,ui) => new
                {
                    UserId = ui.Id,
                    UserName = ui.UserName,
                    UserImg = ui.UserImg,//用户头像
                    WorksId = wk.Id,
                    Title = wk.Title,
                    Content = wk.Content,
                    Sort = wk.Sort,
                    AllowShow = wk.AllowShow,
                    LikesCount = wk.LikesCount,
                    CreatedAt=wk.CreatedAt,
                    PublishedAt = wk.PublishedAt

                })//.ToSql();
                   .ToList();

            return AllList.GroupBy(ui => ui.UserName);//分组，大集合嵌套小集合

        }
        /// <summary>
        /// 根据用户id获取用户信息
        /// </summary>
        /// <param name="Id">用户Id</param>
        /// <returns></returns>
        public TMessage<UserInfo> GetUserInfoByID(int Id) {
            TMessage<UserInfo> mes = new TMessage<UserInfo>();

            var getByPrimaryKey = db.Queryable<UserInfo>().InSingle(Id);
            if (getByPrimaryKey != null)
            {
                mes.suc = true;
                mes.mes = ConstHelper.GET_MODEL_SUCCESS;
                mes.extra = getByPrimaryKey;
            }
            else {
                mes.suc = false;
                mes.mes = ConstHelper.GET_MODEL_ERROR;
            }
            
            return mes;

        }
        /// <summary>
        /// 用户登录验证（用户名与密码）
        /// </summary>
        /// <param name="userName">用户名</param>
        /// <param name="password">密码</param>
        /// <returns></returns>
        public object UserLogin(string userName, string password)
        {
            TMessage<UserInfo> mes = new TMessage<UserInfo>();
            var userLogin = db.Queryable<UserInfo>().Where(it => it.UserName == userName && it.PassWord == password).Any();//.ToSql();
            //string token="";
            if (userLogin)
            {///做到这里了发送用户名密码，获取token
                //mes.extra=token;
                mes.suc = true;
                mes.mes = ConstHelper.USER_LOGIN_SUCCESS;
                mes.token = JwtToken.CreateToken(userName, password).ToString();//用户名与密码生成token
 
            }
            else {
                mes.suc = false;
                mes.mes = ConstHelper.USER_OR_PASSWORD_ERROR;
            }
            return mes;
        }


        public string password { get; set; }
    }
}
