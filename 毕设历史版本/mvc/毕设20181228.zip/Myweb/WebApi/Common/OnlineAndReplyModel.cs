﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Common
{
    /// <summary>
    /// 留言回复的相关model
    /// </summary>
    public class OnlineAndReplyModel
    {
        /// <summary>
        /// 留言id
        /// </summary>
        public int OnlineId { get; set; }
      
    }
}
