﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DAl.Models
{
    public class 公共接收数据的model
    {
    ///    做个记号而已记得删除
    }
}