# TokenSign
token签名认证
博客园链接：http://www.cnblogs.com/MR-YY/p/5972380.html
